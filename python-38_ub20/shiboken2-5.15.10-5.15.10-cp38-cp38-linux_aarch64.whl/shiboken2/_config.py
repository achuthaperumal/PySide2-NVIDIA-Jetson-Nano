shiboken_library_soversion = str(5.15)

version = "5.15.10"
version_info = (5, 15, 10, "", "")

__build_date__ = '2023-12-18T12:51:30+00:00'




__setup_py_package_version__ = '5.15.10'
